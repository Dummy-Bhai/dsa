﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void submit_Click(object sender, EventArgs e)
        {
            string name = getname.Text;
            string mssg=getmssg.Text;

            string concat=string.Concat(name," ",mssg);

            result.Text = concat;
        }

        private void clear_Click(object sender, EventArgs e)
        {
            getname.Text = "";
            getmssg.Text = "";
            result.Text = "Result: ";
            rbBold.Checked = false;
            rbUnderline.Checked = false;
            rbItalic.Checked = false;
            chColor.Checked = false;
            result.Font = new Font(result.Font, FontStyle.Regular);
            result.ForeColor = Color.Black;
        }

        private void rbBold_CheckedChanged(object sender, EventArgs e)
        {
            if(rbBold.Checked)
            {
                result.Font = new Font(result.Font, FontStyle.Bold);
            }
            
        }

        private void rbUnderline_CheckedChanged(object sender, EventArgs e)
        {
            if (rbUnderline.Checked)
            {
                result.Font = new Font(result.Font, FontStyle.Underline);
            }
            
        }

        private void rbItalic_CheckedChanged(object sender, EventArgs e)
        {
            if(rbItalic.Checked)
            {
                result.Font = new Font(result.Font, FontStyle.Italic);
            }
           
        } 

        private void chColor_CheckedChanged(object sender, EventArgs e)
        {
            if(chColor.Checked)
            {
                result.ForeColor = Color.Red;
            }
            else
            {
                result.ForeColor = Color.Black;
            }
           
        }
    }
}
