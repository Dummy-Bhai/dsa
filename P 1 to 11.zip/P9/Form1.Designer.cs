﻿namespace P9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.getname = new System.Windows.Forms.TextBox();
            this.getmssg = new System.Windows.Forms.TextBox();
            this.submit = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.Label();
            this.rbBold = new System.Windows.Forms.RadioButton();
            this.rbUnderline = new System.Windows.Forms.RadioButton();
            this.rbItalic = new System.Windows.Forms.RadioButton();
            this.chColor = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Shaikh Nadim KSBSCIT058";
            // 
            // getname
            // 
            this.getname.Location = new System.Drawing.Point(16, 46);
            this.getname.Name = "getname";
            this.getname.Size = new System.Drawing.Size(100, 22);
            this.getname.TabIndex = 1;
            // 
            // getmssg
            // 
            this.getmssg.Location = new System.Drawing.Point(16, 94);
            this.getmssg.Name = "getmssg";
            this.getmssg.Size = new System.Drawing.Size(100, 22);
            this.getmssg.TabIndex = 2;
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(16, 151);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(75, 23);
            this.submit.TabIndex = 3;
            this.submit.Text = "Submit";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(123, 150);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(75, 23);
            this.clear.TabIndex = 4;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // result
            // 
            this.result.AutoSize = true;
            this.result.Location = new System.Drawing.Point(16, 212);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(48, 16);
            this.result.TabIndex = 5;
            this.result.Text = "Result:";
            // 
            // rbBold
            // 
            this.rbBold.AutoSize = true;
            this.rbBold.Location = new System.Drawing.Point(19, 275);
            this.rbBold.Name = "rbBold";
            this.rbBold.Size = new System.Drawing.Size(56, 20);
            this.rbBold.TabIndex = 6;
            this.rbBold.TabStop = true;
            this.rbBold.Text = "Bold";
            this.rbBold.UseVisualStyleBackColor = true;
            this.rbBold.CheckedChanged += new System.EventHandler(this.rbBold_CheckedChanged);
            // 
            // rbUnderline
            // 
            this.rbUnderline.AutoSize = true;
            this.rbUnderline.Location = new System.Drawing.Point(108, 275);
            this.rbUnderline.Name = "rbUnderline";
            this.rbUnderline.Size = new System.Drawing.Size(86, 20);
            this.rbUnderline.TabIndex = 7;
            this.rbUnderline.TabStop = true;
            this.rbUnderline.Text = "Underline";
            this.rbUnderline.UseVisualStyleBackColor = true;
            this.rbUnderline.CheckedChanged += new System.EventHandler(this.rbUnderline_CheckedChanged);
            // 
            // rbItalic
            // 
            this.rbItalic.AutoSize = true;
            this.rbItalic.Location = new System.Drawing.Point(219, 275);
            this.rbItalic.Name = "rbItalic";
            this.rbItalic.Size = new System.Drawing.Size(55, 20);
            this.rbItalic.TabIndex = 8;
            this.rbItalic.TabStop = true;
            this.rbItalic.Text = "Italic";
            this.rbItalic.UseVisualStyleBackColor = true;
            this.rbItalic.CheckedChanged += new System.EventHandler(this.rbItalic_CheckedChanged);
            // 
            // chColor
            // 
            this.chColor.AutoSize = true;
            this.chColor.Location = new System.Drawing.Point(19, 338);
            this.chColor.Name = "chColor";
            this.chColor.Size = new System.Drawing.Size(61, 20);
            this.chColor.TabIndex = 13;
            this.chColor.Text = "Color";
            this.chColor.UseVisualStyleBackColor = true;
            this.chColor.CheckedChanged += new System.EventHandler(this.chColor_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.chColor);
            this.Controls.Add(this.rbItalic);
            this.Controls.Add(this.rbUnderline);
            this.Controls.Add(this.rbBold);
            this.Controls.Add(this.result);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.getmssg);
            this.Controls.Add(this.getname);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox getname;
        private System.Windows.Forms.TextBox getmssg;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Label result;
        private System.Windows.Forms.RadioButton rbBold;
        private System.Windows.Forms.RadioButton rbUnderline;
        private System.Windows.Forms.RadioButton rbItalic;
        private System.Windows.Forms.CheckBox chColor;
    }
}

