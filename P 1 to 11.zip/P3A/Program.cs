﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P3A
{
    internal class Program
    {
        static bool isprime(int n)
        {
            if(n==0 || n==1)
            {
                return false;
            }
            for(int i=2; i<n; i++)
            {
                if(n % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            Console.WriteLine("Enter the first number:");
            int n1=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the last number:");
            int n2=Convert.ToInt32(Console.ReadLine());
            for(int i=n1;i<=n2;i++)
            {
                if(isprime(i))
                {
                    Console.Write(i+"\t");
                }
            }
            Console.ReadKey();
        }
    }
}
