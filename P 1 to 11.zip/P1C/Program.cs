﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1C
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            Console.WriteLine("Enter the coordinates of x-axis: ");
            int n1=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the coordinates of y-axis: ");
            int n2=Convert.ToInt32(Console.ReadLine());
            if(n1==0 && n2==0)
            {
                Console.WriteLine("The coordinates represent origin");
            }
            else
            {
                if(n1>0 && n2>0)
                {
                    Console.WriteLine("The quadrant is I");
                }
                else if(n1<0 && n2 > 0)
                {
                    Console.WriteLine("The quadrant is II");
                }
                else if(n1<0 && n2 < 0)
                {
                    Console.WriteLine("The quadrant is III");
                }
                else if(n1>0 && n2 < 0)
                {
                    Console.WriteLine("The quadrant is IV");
                }
            }
            Console.ReadKey();
        }
    }
}
