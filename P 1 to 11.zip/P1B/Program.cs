﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            Console.WriteLine("Enter the first number: ");
            int num1=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second number: ");
            int num2=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Addition: "+(num1+num2));
            Console.WriteLine("Subtraction: "+(num1-num2));
            Console.WriteLine("Multiplication: " + (num1 * num2));
            if(num2==0)
            {
                Console.WriteLine("Cannot Divide By Zero");
            }
            else
            {
                Console.WriteLine("Division: "+(num1/num2));
            }
            Console.ReadKey();
        }
    }
}
