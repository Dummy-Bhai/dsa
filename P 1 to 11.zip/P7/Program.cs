﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class EvenNumberException:Exception
{
    public EvenNumberException()
    {
    }
}
namespace P7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            Console.WriteLine("Enter the number: ");
            n=Convert.ToInt32(Console.ReadLine());
            try
            {
                if(n==0)
                {
                    throw new EvenNumberException();
                }
                else if (n % 2 == 0)
                {
                    Console.WriteLine(n + " is an even number");
                }
                else
                {
                    throw new EvenNumberException();
                }
            }
            catch(EvenNumberException e)
            {
                Console.WriteLine(e.ToString());
            }
            catch(Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            Console.ReadKey();
        }
    }
}
