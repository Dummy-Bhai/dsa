﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void check_Click(object sender, EventArgs e)
        {
           int n = Convert.ToInt32(getnum.Text);
            string data = n.ToString();
            int i = n, r = 0;
            string str = "";
            while (i > 0)
            {
                r = i % 10;
                str = str + r;
                i/= 10;
            }
            MessageBox.Show(str);
            if (data.Equals(str))
            {
                lbldisplay.Text = "Result: " + n + " is a Palindrome";
            }
            else
            {
                lbldisplay.Text = "Result: "+n + " is not a Palindrome";
            }
        }
    }
}
