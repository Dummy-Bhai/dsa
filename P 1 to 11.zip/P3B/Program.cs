﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P3B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            Console.WriteLine("Enter the number: ");
            int a=Convert.ToInt32(Console.ReadLine());
            int r = 0, n = a,s=0;
            string str = "";
            while(n>0)
            {
                r = n % 10;
                s = s + r;
                str = str + r;
                n /= 10;
            }
            Console.WriteLine("Reverse Number: "+str+"\nSum of digits: "+s);
            Console.ReadKey();
        }
    }
}
