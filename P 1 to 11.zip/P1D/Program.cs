﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1D
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            string str = "z";
            String data=str.ToLower();
            switch (data)
            {
                case "a":
                    Console.WriteLine(str + " is a vowel");
                    break;
                case "e":
                    Console.WriteLine(str + " is a vowel");
                    break;
                case "i":
                    Console.WriteLine(str + " is a vowel");
                    break;
                case "o":
                    Console.WriteLine(str + " is a vowel");
                    break;
                case "u":
                    Console.WriteLine(str + " is a vowel");
                    break;
                default:
                    Console.WriteLine(str + " is not a vowel");
                    break;
            }
            Console.ReadKey();
        }
    }
}
