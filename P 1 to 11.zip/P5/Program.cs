﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class salary
{
    double Basic, TA;
    double DA=2500, HRA=10000;
    public salary(double b,double ta)
    {
        Basic = b;
        TA = ta;
        Console.WriteLine("The employee salary is " + (Basic+TA+DA+HRA));
    }
}
namespace P5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            salary obj=new salary(50000,3000);
            Console.ReadKey();
        }
    }
}
