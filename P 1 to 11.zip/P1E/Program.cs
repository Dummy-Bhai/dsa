﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1E
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            string str = "Hello World";
            foreach (char arg in str)
            {
                Console.Write(arg);
            }
            Console.ReadKey();
        }
    }
}
