﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class A
{
    public A()
    {
        Console.WriteLine("Class A is Called");
    }
    public static void myMethod()
    {
        Console.WriteLine("Class A method is called");
    }
}

namespace P2A
{
    internal class Program:A
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            Program program = new Program();
            myMethod();

            Console.ReadKey();
        }
    }

}
