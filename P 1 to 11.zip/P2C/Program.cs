﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public interface A
{
    void method();
}
public interface B
{
    void method();
}
class get : A, B
{
    public void method()
    {
        Console.WriteLine("Interface method is called");
    }
}
namespace P2C
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            get g=new get();
            g.method();
            Console.ReadKey();
        }
    }
}
