﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void vote_Click(object sender, EventArgs e)
        {
            if(radioButton1.Checked)
            {
                int p = 100;
                label3.Text ="Result: "+p.ToString()+"%";
            }
            else if(radioButton2.Checked)
            {
                int p = 50;
                label3.Text = "Result: " + p.ToString() + "%";
            }
            else if(radioButton3.Checked)
            {
                int p = 10;
                label3.Text = "Result: " + p.ToString() + "%";
            }
            else
            {

            }
        }
    }
}
