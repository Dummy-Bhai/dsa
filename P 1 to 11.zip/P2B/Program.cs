﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class A
{
    public A()
    {
        Console.WriteLine("Class A is Called");
    }
}
class B : A
{
    public B()
    {
        Console.WriteLine("Class B is Called");
    }
}
namespace P2B
{
    internal class Program:B
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            Program program = new Program();
            Console.ReadKey();
        }
    }
}
