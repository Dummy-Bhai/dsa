﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            emplist.Items.Add("Nadim");
            emplist.Items.Add("Allen");
            emplist.Items.Add("John");
            emplist.Items.Add("Anas");
            emplist.Items.Add("Elon");
        }

        private void get_Click(object sender, EventArgs e)
        {
            if(emplist.SelectedItems.Count > 0)
            {
                foreach(var emp in emplist.SelectedItems)
                {
                    getemp.AppendText(emp.ToString()+Environment.NewLine);
                }
            }
        }
    }
}
