﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P3C
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            string str = "I Love Java";
            str = str.ToLower();
            Console.WriteLine("The vowels in the string are: ");
            for(int i=0;i<str.Length;i++)
            {
                switch(str[i])
                {
                    case 'a':
                        Console.Write(str[i] + "\t");
                        continue;
                    case 'e':
                        Console.Write(str[i] + "\t");
                        continue;
                    case 'i':
                        Console.Write(str[i] + "\t");
                        continue;
                    case 'o':
                        Console.Write(str[i] + "\t");
                        continue;
                    case 'u':
                        Console.Write(str[i] + "\t");
                        continue;
                    default:
                        continue;
                }
            }
            Console.ReadKey();
        }
    }
}
