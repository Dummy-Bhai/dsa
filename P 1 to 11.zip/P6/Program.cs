﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Employee
{
    public string name, age, post;
    public virtual void display(string n,string a)
    {
        this.name = n;
        this.age = a;
    }
}
class Programmer: Employee
{
    public override void display(string n, string a)
    {
        name = n;
        age = a;
        post= "Programmer";
        Console.WriteLine("The Programmer Details is;\nName: " + name + "\nAge: " + age + "\nPost: " + post);
    }
}
class Manager : Employee
{
    public override void display(string n, string a)
    {
        name = n;
        age = a;
        post = "Manager";
        Console.WriteLine("The Manager Details is;\nName: " + name + "\nAge: " + age + "\nPost: " + post);
    }
}
namespace P6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            Programmer programmer = new Programmer();
            Manager manager = new Manager();
            programmer.display("Shaikh Nadim","19");
            manager.display("Khan Shab", "20");
            Console.ReadKey();
        }
    }
}
