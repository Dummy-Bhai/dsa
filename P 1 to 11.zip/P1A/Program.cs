﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1A
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            Console.WriteLine("Enter the side of a triangle:");
            dynamic side=Convert.ToInt32(Console.ReadLine());
            dynamic side1= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("The hypotenuse of a triangle is "+(Math.Sqrt(side*side+side1*side1)));
            Console.ReadKey();
        }
    }
}
