﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class staff
{
    public string[] name=new string[5];
    public string[] post=new string[5];
    public void get()
    {
        for(int i= 0;i<5;i++)
        {
            Console.WriteLine("Enter the Name: ");
            name[i]=Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter the Post: ");
            post[i]=Convert.ToString(Console.ReadLine());
        }
    }
    public void display()
    {
        Console.WriteLine("The staff that are HOD are;");
        for(int i= 0;i<name.Length;i++)
        {
            if (post[i].ToLower()=="hod")
            {
                Console.WriteLine(name[i]);
            }
        }
    }
}
namespace P4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shaikh Nadim KSBSCIT058");
            staff obj = new staff();
            obj.get();
            obj.display();
            Console.ReadKey();
        }
    }
}
